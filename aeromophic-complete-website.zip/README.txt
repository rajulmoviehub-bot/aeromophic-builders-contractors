AEROMOPHIC WEBSITE PACKAGE

This ZIP is for the Aeromophic Construction Works website ONLY.
It is not for the VERTEX project.

CONTENTS
- index.html: complete responsive website
- README.txt: these instructions

INCLUDED
- Mobile-friendly black and gold design and mobile navigation
- About, services, process, project gallery, testimonials carousel slot, NCA note, FAQs and contact
- Phone, email and WhatsApp links
- Quotation form that opens WhatsApp; it does not save customer data
- Basic SEO metadata, social sharing metadata and business structured data
- Accessibility labels, reduced-motion support and image lazy-loading

TESTIMONIALS
The testimonial area is prepared for automatic rotation. It deliberately contains no made-up customer reviews.
Add only genuine feedback supplied and approved by the client before publishing.

UPLOAD
1. Download and extract this ZIP.
2. Open GitHub repository: rajulmoviehub-bot/aeromophic-builders-contractors
3. Open the root-level index.html and replace its full contents with the supplied index.html, OR upload the extracted index.html to the repository root and confirm replacement.
4. Keep the filename exactly: index.html
5. Commit the change to the production branch. Vercel should redeploy automatically.

IMPORTANT
- The gallery uses clearly labelled illustrative photos. Replace them with actual company project photos only when supplied and approved.
- Confirm current NCA registration, practising licence and contract limit before accepting any project.
- Check the phone numbers, email, domain, business name and legal details before publishing.
